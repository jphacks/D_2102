package com.example.jphacks_server.entity;

public class Schools {

    private int schoolsId;
    private String schoolsName;

    public int getSchoolsId() {
        return schoolsId;
    }

    public void setSchoolsId(int schoolsId) {
        this.schoolsId = schoolsId;
    }

    public String getSchoolsName() {
        return schoolsName;
    }

    public void setSchoolsName(String schoolsName) {
        this.schoolsName = schoolsName;
    }
}
