package com.example.jphacks_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JphacksServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
